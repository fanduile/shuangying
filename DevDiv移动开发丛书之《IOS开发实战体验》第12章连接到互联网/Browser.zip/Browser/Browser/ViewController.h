//
//  ViewController.h
//  Browser
//
//  Created by Kevin Zhao on 11-11-28.
//  Copyright (c) 2011年 FH. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
    //Web视图
    UIWebView *webView_;
    
    //地址栏
    UITextField *addressField_;
}

@property(nonatomic, retain)IBOutlet UIWebView *webView;
@property(nonatomic, retain)IBOutlet UITextField *addressField;

//前往
- (IBAction)go:(id)sender;

//前进
- (IBAction)goForward:(id)sender;

//回退
- (IBAction)goBack:(id)sender;

//停止
- (IBAction)stopLoading:(id)sender;

//刷新
- (IBAction)reload:(id)sender;

@end

//
//  ViewController.m
//  Browser
//
//  Created by Kevin Zhao on 11-11-28.
//  Copyright (c) 2011年 FH. All rights reserved.
//

#import "ViewController.h"

@implementation ViewController

@synthesize webView = webView_;
@synthesize addressField = addressField_;

#pragma mark - View options

//前往
- (IBAction)go:(id)sender
{
    NSURL *url = [[NSURL alloc] initWithString:[[self addressField] text]];
    NSURLRequest *request = [[NSURLRequest alloc] initWithURL:url];
    [[self webView] loadRequest:request];
    [request release];
    [url release];
}

//前进
- (IBAction)goForward:(id)sender
{
    [[self webView]goForward];
}

//回退
- (IBAction)goBack:(id)sender
{
    [[self webView] goBack];
}

//停止
- (IBAction)stopLoading:(id)sender
{
    [[self webView] stopLoading];
}

//刷新
- (IBAction)reload:(id)sender
{
    [[self webView] reload];
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    [webView_ release];
}


@end

//
//  ViewController.h
//  NSXMLParserDemo
//
//  Created by Kevin Zhao on 11-11-30.
//  Copyright (c) 2011年 FH. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<NSXMLParserDelegate>
{
    
}


- (IBAction)processXMLData:(id)sender;

@end

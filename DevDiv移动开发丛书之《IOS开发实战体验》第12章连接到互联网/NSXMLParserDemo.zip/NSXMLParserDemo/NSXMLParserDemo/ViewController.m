//
//  ViewController.m
//  NSXMLParserDemo
//
//  Created by Kevin Zhao on 11-11-30.
//  Copyright (c) 2011年 FH. All rights reserved.
//

#import "ViewController.h"

@implementation ViewController


- (IBAction)processXMLData:(id)sender
{
    NSData *xmlData = [NSData dataWithContentsOfFile:@"device.xml"];
    NSXMLParser *parser = [[NSXMLParser alloc] initWithData:xmlData];
    [parser setShouldProcessNamespaces:NO];
    [parser setShouldReportNamespacePrefixes:NO];
    [parser setShouldResolveExternalEntities:NO];
    [parser setDelegate:self];
    [parser parse];

}


- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict
{
    NSLog(@"Name:%@",elementName);
}


- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
    NSLog(@"Value:%@",string);
}


//
- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName
{
    
}


#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    NSData *xmlData = [NSData dataWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"device" ofType:@"xml"]];
    NSXMLParser *parser = [[NSXMLParser alloc] initWithData:xmlData];
    [parser setShouldProcessNamespaces:NO];
    [parser setShouldReportNamespacePrefixes:NO];
    [parser setShouldResolveExternalEntities:NO];
    [parser setDelegate:self];
    [parser parse];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
}

@end

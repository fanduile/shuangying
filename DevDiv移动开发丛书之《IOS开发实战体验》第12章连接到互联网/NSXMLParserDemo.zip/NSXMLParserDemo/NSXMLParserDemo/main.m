//
//  main.m
//  NSXMLParserDemo
//
//  Created by Kevin Zhao on 11-11-30.
//  Copyright (c) 2011年 FH. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}

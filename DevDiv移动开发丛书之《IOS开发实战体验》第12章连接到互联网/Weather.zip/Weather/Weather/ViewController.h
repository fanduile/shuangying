//
//  ViewController.h
//  Weather
//
//  Created by Kevin Zhao on 11-11-30.
//  Copyright (c) 2011年 FH. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
    //用于输入地区
    UITextField *areaNameField_;
    
    //用于显示图片
    UIWebView *iconView_;
    
    //用于显示天气
    UILabel *weatherLabel_;
    
    //用于显示温度
    UILabel *tempLabel_;
    
    //
    UILabel *hLabel_;
    
    //用于显示风向及风速
    UILabel *windLabel_;
    
}

@property(nonatomic, retain)IBOutlet UITextField *areaNameField;
@property(nonatomic, retain)IBOutlet UIWebView *iconView;
@property(nonatomic, retain)IBOutlet UILabel *weatherLabel;
@property(nonatomic, retain)IBOutlet UILabel *tempLabel;
@property(nonatomic, retain)IBOutlet UILabel *windLabel;
@property(nonatomic, retain)IBOutlet UILabel *hLabel;

- (IBAction)processWeatherInfo:(id)sender;

- (void)doParse:(NSString *)xmlString;

@end

//
//  ViewController.m
//  Weather
//
//  Created by Kevin Zhao on 11-11-30.
//  Copyright (c) 2011年 FH. All rights reserved.
//

#import "ViewController.h"
#import "TouchXML.h"
@implementation ViewController

@synthesize areaNameField = areaNameField_;
@synthesize iconView = iconView_;
@synthesize weatherLabel = weatherLabel_;
@synthesize tempLabel = tempLabel_;
@synthesize windLabel = windLabel_;
@synthesize hLabel = hLabel_;

static NSString* baseURL = @"http://www.google.com";


//查询
- (IBAction)processWeatherInfo:(id)sender
{
    //隐藏键盘
    [[self areaNameField] resignFirstResponder];
    
    //拼装请求URL
    NSString *searchURL = [NSString stringWithFormat:@"%@/ig/api?hl=zh-cn&weather=%@", baseURL, [[self areaNameField] text]];    
	
    //获取XML数据
    NSMutableData *urlData = [NSMutableData dataWithContentsOfURL:[NSURL URLWithString:searchURL]];
    
    //因为得到的数据不是UTF8 所以需要进行编码转换
    NSStringEncoding enc = CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000);
	NSString *str = [[NSString alloc]initWithData:urlData encoding:enc];
    
    //开始解析
    [self doParse:str];
}


//解析数据
- (void)doParse:(NSString *)xmlString
{
    //生成DOM
    CXMLDocument *doc = [[[CXMLDocument alloc] initWithXMLString:xmlString options:0 error:nil] autorelease];
    
    
    NSArray *currentConditions = [doc nodesForXPath:@"//current_conditions" error:nil];
    
    CXMLElement *currentConditionsElement = [currentConditions objectAtIndex:0];
    
    //天气
    NSArray *weatherElements = [currentConditionsElement elementsForName:@"condition"];
    if ([weatherElements count]) 
    {
        CXMLElement *weatherElement = [weatherElements objectAtIndex:0];
        CXMLNode *weatherData = [weatherElement attributeForName:@"data"];
        [[self weatherLabel] setText:[weatherData stringValue]];
    }
    
    //温度
    NSArray *tempElements = [currentConditionsElement elementsForName:@"temp_c"];
    if ([tempElements count]) 
    {
        CXMLElement *tempElement = [tempElements objectAtIndex:0];
        CXMLNode *tempData = [tempElement attributeForName:@"data"];
        [[self tempLabel] setText:[tempData stringValue]];
    }
    
    //风向风速
    NSArray *hElements = [currentConditionsElement elementsForName:@"humidity"];
    if ([hElements count]) 
    {
        CXMLElement *hElement = [hElements objectAtIndex:0];
        CXMLNode *hData = [hElement attributeForName:@"data"];
        [[self hLabel] setText:[hData stringValue]];
    }
    //风向风速
    NSArray *windElements = [currentConditionsElement elementsForName:@"wind_condition"];
    if ([windElements count]) 
    {
        CXMLElement *windElement = [windElements objectAtIndex:0];
        CXMLNode *windData = [windElement attributeForName:@"data"];
        [[self windLabel] setText:[windData stringValue]];
    }
    
    //风向风速
    NSArray *iconElements = [currentConditionsElement elementsForName:@"icon"];
    if ([iconElements count]) 
    {
        CXMLElement *iconElement = [iconElements objectAtIndex:0];
        CXMLNode *iconData = [iconElement attributeForName:@"data"];
        NSString *iconURL = [NSString stringWithFormat:@"%@%@", baseURL, [iconData stringValue]];
        NSURLRequest *iconRequest = [NSURLRequest requestWithURL:[NSURL URLWithString:iconURL]];
        [[self iconView] loadRequest:iconRequest];
    }
}


#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
}

@end
